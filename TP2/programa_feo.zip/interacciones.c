#include <stdio.h>
//#include "interacciones.h"
#include "structs.h"

#define MAX_POKEMON_COMBATE 6

#define SIMULACION 'S'

#define ROJO "\x1b[91m"
#define AMARILLO "\x1b[93m"
#define VERDE "\x1b[92m"
#define MAGENTA "\x1b[95m"
#define NORMAL "\x1b[0m"
#define FLECHA "→"

char menu_inicio(char archivo_personaje[MAX_NOMBRE], char archivo_gimnasio[MAX_NOMBRE]){

    char opcion;    

    printf(" ┌──────────────────"AMARILLO" MENU INICIO "NORMAL"──────────────────┐\n");
    printf(" │ "VERDE"E"NORMAL": ingresa el archivo del entrenador principal. │\n │ "VERDE"A"NORMAL": agrega un gimnasio al arbol de gimnasios.    │\n │ "VERDE"I"NORMAL": comienza la partida.                         │\n │ "VERDE"S"NORMAL": simula la partida.                           │\n");
    printf(" └─────────────────────────────────────────────────┘\n");
    scanf(" %c", &opcion);

    if(opcion != 'E' && opcion != 'A' && opcion != 'I' && opcion != 'S'){
        printf(" Debes ingresar un comando valido.\n");
        menu_inicio(archivo_personaje, archivo_gimnasio);    
    }

    if((opcion == 'I' || opcion == 'S') && (archivo_personaje[0] == '\0' || archivo_gimnasio[0] == '\0')){
        printf(ROJO" ¡Atencion!"NORMAL" No se ha ingresado el archivo del entrenador principal ni se ha agregado un gimnasio.\n");
        printf(" ┌─────────────────────────────────────────────────┐\n");
        printf(" │ "VERDE"E" NORMAL": ingresa el archivo del entrenador principal. │\n │ "VERDE"A"NORMAL": agrega un gimnasio al arbol de gimnasios.    │\n");
        printf(" └─────────────────────────────────────────────────┘\n");
        scanf(" %c", &opcion);
        while(opcion != 'E' && opcion != 'A'){
            printf(" Debes ingresar un comando valido.\n");
            printf(" ┌─────────────────────────────────────────────────┐\n");
            printf(" │ "VERDE"E" NORMAL": ingresa el archivo del entrenador principal. │\n │ "VERDE"A"NORMAL": agrega un gimnasio al arbol de gimnasios.    │\n");
            printf(" └─────────────────────────────────────────────────┘\n");
            scanf(" %c", &opcion);    
        }
    }    
    if(opcion == 'E'){
        printf(VERDE FLECHA NORMAL" Ingrese la ruta del archivo del entrenador principal: \n");
        scanf(" %s", archivo_personaje);
        printf("\n");
        printf(VERDE FLECHA NORMAL" Agrega un gimnasio al arbol de gimnasios: \n\n");
        scanf(" %s", archivo_gimnasio);
    }

    printf(" ┌──────────────────"AMARILLO" MENU INICIO "NORMAL"──────────────────┐\n");
    printf(" │ "VERDE"I"NORMAL": comienza la partida.                         │\n │ "VERDE"S"NORMAL": simula la partida.                           │\n");
    printf(" └─────────────────────────────────────────────────┘\n");
    scanf(" %c", &opcion);
    while(opcion != 'I' && opcion != 'S'){
        printf(" Debes ingresar un comando valido.\n");
        printf(" ┌──────────────────"AMARILLO" MENU INICIO "NORMAL"──────────────────┐\n");
        printf(" │ "VERDE"I"NORMAL": comienza la partida.                         │\n │ "VERDE"S"NORMAL": simula la partida.                           │\n");
        printf(" └─────────────────────────────────────────────────┘\n");
        scanf(" %c", &opcion);    
    }
    return opcion;
}

void mostrar_info_personaje(personaje_principal_t* personaje){    
    printf("──────── POKEMON DE COMBATE ────────\n");
    printf("POKEMON │ VELOCIDAD │ ATAQUE │ DEFENSA\n");
    for(size_t i = 0; i < personaje->cola_pokemon_combate->cantidad; i++){
        pokemon_t* pokemon = lista_elemento_en_posicion(personaje->cola_pokemon_combate, i);
        printf("%li) %s  │", i, pokemon->nombre);
        printf("%i  │", pokemon->velocidad);
        printf("%i  │", pokemon->ataque);
        printf("%i\n", pokemon->defensa);
    }
    printf("──────── POKEMON OBTENIDOS ────────\n");
    printf("POKEMON │ VELOCIDAD │ ATAQUE │ DEFENSA\n");
    for(size_t i = 0; i < personaje->lista_pokemon_obtenidos->cantidad; i++){
        pokemon_t* pokemon = lista_elemento_en_posicion(personaje->lista_pokemon_obtenidos, i);
        printf("%li) %s  │", i, pokemon->nombre);
        printf("%i  │", pokemon->velocidad);
        printf("%i  │", pokemon->ataque);
        printf("%i\n", pokemon->defensa);
    }
}

void mostrar_info_entrenador(entrenador_t* entrenador){
   
    for(size_t i = 0; i < entrenador->lista_pokemon->cantidad; i++){
        pokemon_t* pokemon = lista_elemento_en_posicion(entrenador->lista_pokemon, i);
        printf("%li) %s  │", i, pokemon->nombre);
        printf("%i  │", pokemon->velocidad);
        printf("%i  │", pokemon->ataque);
        printf("%i\n", pokemon->defensa);
    }
}

void mostrar_info_gimnasio(gimnasio_t* gimnasio){
    printf(VERDE"%s"NORMAL", dificultad: %i\n", gimnasio->nombre, gimnasio->dificultad);
    printf("──────── LIDER ────────\n");
    entrenador_t* lider = lista_primero(gimnasio->pila_entrenadores);
    printf("Nombre: %s\n", lider->nombre);
    printf("──────── ENTRENADORES ────────\n");
    for(size_t i = 1; i < (gimnasio->pila_entrenadores->cantidad); i++){
        entrenador_t* lider = lista_elemento_en_posicion(gimnasio->pila_entrenadores, i);
        printf("Nombre: %s\n", lider->nombre);
    }
}

void cambiar_pokemon(personaje_principal_t* personaje){
    size_t posicion = 0;
    for(int i = 0; i < MAX_POKEMON_COMBATE; i++)
        lista_desencolar(personaje->cola_pokemon_combate);
    mostrar_info_personaje(personaje);
    printf("Ingrese el numero de los 6 pokemon que quiere agregar: \n");
    while(personaje->cola_pokemon_combate->cantidad < MAX_POKEMON_COMBATE){
        scanf("%zu", &posicion);        
        pokemon_t* pokemon = (pokemon_t*)lista_elemento_en_posicion(personaje->lista_pokemon_obtenidos, posicion);
        lista_encolar(personaje->cola_pokemon_combate, pokemon);
        mostrar_info_personaje(personaje);
    }
}

void menu_gimnasio(gimnasio_t* gimnasio, personaje_principal_t* personaje_principal){
    
    char opcion;

    printf(" ┌──────────────"AMARILLO" MENU GIMANSIO "NORMAL"──────────────┐\n");
    printf(" │ "VERDE"E"NORMAL": Informacion personaje principal        │\n │ "VERDE"G"NORMAL": Informacion del gimnasio actual        │\n │ "VERDE"C"NORMAL": Cambiar pokemon de combate             │\n │ "VERDE"B"NORMAL": Proxima batalla                        │\n");
    printf(" └───────────────────────────────────────────┘\n");
    scanf(" %c", &opcion);
    if(opcion != 'E' && opcion != 'G' && opcion != 'C' && opcion != 'B'){
        printf(" Debes ingresar un comando valido.\n");
        menu_gimnasio(gimnasio, personaje_principal);
    }
    if(opcion == 'E'){
        printf("Nombre: %s\n", personaje_principal->nombre);
        mostrar_info_personaje(personaje_principal);
        menu_gimnasio(gimnasio, personaje_principal);
    }
    if(opcion == 'G'){
        mostrar_info_gimnasio(gimnasio);
        menu_gimnasio(gimnasio, personaje_principal);
    }
    if(opcion == 'C'){
        cambiar_pokemon(personaje_principal);
        menu_gimnasio(gimnasio, personaje_principal);
    }
    if(opcion == 'B')
        return;
}

void menu_batalla(personaje_principal_t* personaje, pokemon_t* pokemon_personaje, entrenador_t* entrenador, pokemon_t* pokemon_entrenador, int ganador, char opcion){
    char proximo_combate;
    printf(VERDE"ENTRENADOR:"NORMAL" %s  | "VERDE"ENTRENADOR:"NORMAL" %s\n", personaje->nombre, entrenador->nombre);
    printf("─────────────────────────────────────────────────\n");
    printf("Pokemon: %s       | Pokemon: %s\n", pokemon_personaje->nombre, pokemon_entrenador->nombre);
    printf(FLECHA" Velocidad: %i | Velocidad: %i\n", pokemon_personaje->velocidad, pokemon_entrenador->velocidad);
    printf(FLECHA" Ataque: %i    | Ataque: %i\n", pokemon_personaje->ataque, pokemon_entrenador->ataque);
    printf(FLECHA" Defensa: %i   | Defensa: %i\n", pokemon_personaje->defensa, pokemon_entrenador->defensa);
    printf("─────────────────────────────────────────────────\n");
    if(ganador == 1)
        printf("Ganador: %s\n", personaje->nombre);
    else
        printf("Ganador: %s\n", entrenador->nombre);
    if(opcion != SIMULACION){
        printf("N: Proximo combate.\n");
        scanf(" %c", &proximo_combate);
        while(proximo_combate != 'N'){
            printf(ROJO"N: Proximo combate dije.\n"NORMAL);
            scanf(" %c", &proximo_combate);
        }
    } 
}

void tomar_pokemon(personaje_principal_t* personaje, gimnasio_t* gimnasio){
    size_t posicion = 0;
    entrenador_t* lider = (entrenador_t*)lista_primero(gimnasio->pila_entrenadores);
    printf("POKEMON DEL LIDER:\n");
    mostrar_info_entrenador(lider);
    printf("Elige el numero del pokemon que quieres agregar a tu lista de pokemon obtenidos:\n");
    scanf("%zu", &posicion);
    pokemon_t* pokemon = (pokemon_t*)lista_elemento_en_posicion(lider->lista_pokemon, posicion);
    lista_insertar(personaje->lista_pokemon_obtenidos, pokemon);
    mostrar_info_personaje(personaje);
}

void menu_victoria(personaje_principal_t* personaje, gimnasio_t* gimnasio){
    char opcion;
    printf("T: Toma un pokemon del lider y lo incorpora en los pokemon obtenidos del jugador.\n");
    printf("C: Permite cambiar los pokemon de batalla.\n");
    printf("N: proximo gimnasio.\n");
    scanf(" %c", &opcion);
    if(opcion != 'T' && opcion != 'C' && opcion != 'N'){
        printf(" Debes ingresar un comando valido.\n");
        menu_victoria(personaje, gimnasio);
    }
    if(opcion == 'T'){
        tomar_pokemon(personaje, gimnasio);
        printf("C: Permite cambiar los pokemon de batalla.\n");
        printf("N: proximo gimnasio.\n");
        scanf(" %c", &opcion);
        while(opcion != 'C' && opcion != 'N'){
            printf("C: Permite cambiar los pokemon de batalla.\n");
            printf("N: proximo gimnasio.\n");
            scanf(" %c", &opcion);
        }
        if(opcion == 'C'){
            cambiar_pokemon(personaje);
            return;
        }else return;
    }
    if(opcion == 'C'){
        cambiar_pokemon(personaje);
    }else return;
}

char menu_derrota(personaje_principal_t* personaje){
    char opcion;    

    printf(" ┌──────────────────"AMARILLO" MENU INICIO "NORMAL"──────────────────┐\n");
    printf(" │ "VERDE"C"NORMAL": Cambiar pokemon de combate │\n │ "VERDE"R"NORMAL": Reintentar gimnasio    │\n │ "VERDE"F"NORMAL": Finalizar la partida                         │\n");
    printf(" └─────────────────────────────────────────────────┘\n");
    scanf(" %c", &opcion);

    while(opcion != 'C' && opcion != 'R' && opcion != 'F'){
        printf(" Debes ingresar un comando valido.\n");
        menu_derrota(personaje);    
    }
    if(opcion == 'C'){
        cambiar_pokemon(personaje);
        menu_derrota(personaje);
    }
    return opcion;
}